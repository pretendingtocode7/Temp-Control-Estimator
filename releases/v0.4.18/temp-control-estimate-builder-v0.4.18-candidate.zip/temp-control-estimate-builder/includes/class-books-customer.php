<?php
/** Resolve a CRM account to a Books customer before generating a draft or issuing a choice link. */
declare( strict_types=1 );

namespace TempControl\Estimate;

use WP_Error;

defined( 'ABSPATH' ) || exit;

final class Books_Customer {
	public static function resolve( array $account, string $org ): string|WP_Error {
		$account_id = Security::instance()->sanitize_zoho_id( (string) ( $account['id'] ?? '' ) );
		$email = strtolower( trim( (string) ( $account['email'] ?? '' ) ) );
		if ( '' === $account_id || '' === $org ) {
			return self::review();
		}
		if ( ! is_email( $email ) ) {
			return new WP_Error( 'tc_estimate_books_customer_no_email', __( 'The selected CRM account needs a valid customer email address.', 'tc-estimate' ), array( 'status' => 400 ) );
		}

		// Query the configured Books organization afresh. A shared email is never a cache key.
		$mapped = self::contacts( $org, array( 'zcrm_account_id' => $account_id ) );
		if ( is_wp_error( $mapped ) ) {
			return $mapped;
		}
		$has_mapping = ! empty( $mapped );
		$candidates = $mapped;
		if ( ! $has_mapping ) {
			// Combine both searches used by the original generator before deciding uniqueness.
			foreach ( array( 'email', 'search_text' ) as $field ) {
				$found = self::contacts( $org, array( $field => $email ), $email );
				if ( is_wp_error( $found ) ) {
					return $found;
				}
				$candidates += $found;
			}
		}
		if ( empty( $candidates ) ) {
			return new WP_Error( 'tc_estimate_books_customer_not_found', __( 'No active Zoho Books customer matches this CRM account and email.', 'tc-estimate' ), array( 'status' => 409 ) );
		}
		if ( 1 !== count( $candidates ) ) {
			return self::review();
		}

		$id = (string) array_key_first( $candidates );
		$expected = trim( (string) ( $account['crm_customer_number'] ?? '' ) );
		if ( '' !== $expected && $expected !== $id ) {
			return self::review();
		}
		$contact = self::contact( $org, $id );
		if ( is_wp_error( $contact ) ) {
			return $contact;
		}
		$reverse = (string) ( $contact['zcrm_account_id'] ?? '' );
		if ( ! self::has_email( $contact, $email ) ) {
			return self::review();
		}
		if ( '' !== $reverse && $account_id !== $reverse ) {
			return self::review();
		}
		// A result from the CRM-ID filter needs corroboration from either side of the sync.
		if ( $has_mapping && '' === $reverse && $expected !== $id ) {
			return self::review();
		}
		return $id;
	}

	/** Return distinct active customer IDs. An incomplete or malformed result cannot prove uniqueness. */
	private static function contacts( string $org, array $filter, string $exact_email = '' ): array|WP_Error {
		$query = $filter + array( 'organization_id' => $org, 'contact_type' => 'customer', 'filter_by' => 'Status.Active', 'per_page' => 200 );
		$result = Zoho_API::instance()->get( Zoho_API::SERVICE_BOOKS, '/contacts', $query );
		if ( is_wp_error( $result ) || 0 !== ( $result['code'] ?? null ) || ! is_array( $result['contacts'] ?? null ) || false !== ( $result['page_context']['has_more_page'] ?? null ) ) {
			return self::incomplete();
		}
		$matches = array();
		foreach ( $result['contacts'] as $row ) {
			if ( ! is_array( $row ) || empty( $row['status'] ) || empty( $row['contact_type'] ) ) {
				return self::incomplete();
			}
			if ( 'active' !== $row['status'] || 'customer' !== $row['contact_type'] ) {
				continue;
			}
			$id = Security::instance()->sanitize_zoho_id( (string) ( $row['contact_id'] ?? '' ) );
			if ( '' === $id ) {
				return self::incomplete();
			}
			if ( ! empty( $filter['zcrm_account_id'] ) && ! empty( $row['zcrm_account_id'] ) && (string) $row['zcrm_account_id'] !== $filter['zcrm_account_id'] ) {
				return self::review();
			}
			// A list row can omit the matching contact person's email. Check the detail
			// before excluding a row returned by the email filter from the count.
			if ( isset( $filter['email'] ) && ! self::has_email( $row, $exact_email ) ) {
				$row = self::contact( $org, $id );
				if ( is_wp_error( $row ) ) {
					return $row;
				}
			}
			if ( '' === $exact_email || self::has_email( $row, $exact_email ) ) {
				$matches[ $id ] = true;
			}
		}
		return $matches;
	}

	private static function contact( string $org, string $id ): array|WP_Error {
		$result = Zoho_API::instance()->get( Zoho_API::SERVICE_BOOKS, '/contacts/' . $id, array( 'organization_id' => $org ) );
		if ( is_wp_error( $result ) || 0 !== ( $result['code'] ?? null ) || ! is_array( $result['contact'] ?? null ) ) {
			return self::incomplete();
		}
		$contact = $result['contact'];
		if ( $id !== (string) ( $contact['contact_id'] ?? '' ) || 'active' !== ( $contact['status'] ?? '' ) || 'customer' !== ( $contact['contact_type'] ?? '' ) ) {
			return self::review();
		}
		return $contact;
	}

	private static function has_email( array $contact, string $email ): bool {
		$emails = array( $contact['email'] ?? '', $contact['primary_contact_email'] ?? '' );
		foreach ( (array) ( $contact['contact_persons'] ?? array() ) as $person ) {
			if ( is_array( $person ) ) {
				$emails[] = $person['email'] ?? '';
			}
		}
		foreach ( $emails as $value ) {
			if ( is_string( $value ) && strtolower( trim( $value ) ) === $email ) {
				return true;
			}
		}
		return false;
	}

	private static function review(): WP_Error {
		return new WP_Error( 'tc_estimate_books_customer_review', __( 'The Books customer is ambiguous or conflicts with the CRM account. Review the customer mapping in Zoho before continuing.', 'tc-estimate' ), array( 'status' => 409 ) );
	}

	private static function incomplete(): WP_Error {
		return new WP_Error( 'tc_estimate_books_customer_lookup', __( 'Zoho Books did not return a complete customer lookup. Customer verification is required before continuing.', 'tc-estimate' ), array( 'status' => 502 ) );
	}
}
