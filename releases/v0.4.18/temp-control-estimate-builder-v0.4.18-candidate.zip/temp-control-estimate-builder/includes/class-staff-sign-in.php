<?php
/** Estimate Builder-only passwordless sign-in for one enrolled work account. */
declare( strict_types=1 );

namespace TempControl\Estimate;

defined( 'ABSPATH' ) || exit;

final class Staff_Sign_In {
	public const ROLE = 'tc_estimate_operator';
	public const CAP = 'tc_build_estimates';
	// WP Engine forwards wordpress_ session cookies through its cache tier.
	private const COOKIE = '__Host-wordpress_tc_estimate_challenge';
	private const STORE = 'tc_estimate_staff_challenge_v1';
	private const LIFETIME = 600;
	private const SENDS_PER_HOUR = 5;
	private const TRIES = 5;

	public static function register(): void {
		add_action( 'template_redirect', array( self::class, 'handle' ), 0 );
		add_action( 'admin_init', array( self::class, 'protect_dashboard' ), 0 );
		add_filter( 'wp_authenticate_user', array( self::class, 'prevent_password_login' ), 99 );
		add_filter( 'allow_password_reset', array( self::class, 'prevent_password_reset' ), 99, 2 );
		add_filter( 'wp_is_application_passwords_available_for_user', array( self::class, 'prevent_app_passwords' ), 99, 2 );
		add_filter( 'rest_pre_dispatch', array( self::class, 'protect_rest' ), 0, 3 );
		add_filter( 'show_admin_bar', array( self::class, 'toolbar' ), 99 );
	}

	public static function install_role(): void {
		add_role( self::ROLE, 'Estimate Builder operator', array( 'read' => true, self::CAP => true ) );
	}

	private static function email(): string {
		return defined( 'TC_ESTIMATE_STAFF_SIGN_IN_EMAIL' ) && is_string( TC_ESTIMATE_STAFF_SIGN_IN_EMAIL )
			? strtolower( trim( TC_ESTIMATE_STAFF_SIGN_IN_EMAIL ) ) : '';
	}

	public static function operator_role( $user ): bool {
		return $user instanceof \WP_User && in_array( self::ROLE, (array) $user->roles, true );
	}

	/** Reject additional roles or granted capabilities; never sign in an administrator. */
	public static function eligible_operator( $user ): bool {
		if ( ! self::operator_role( $user ) || array_values( $user->roles ) !== array( self::ROLE ) || ! empty( $user->user_status ) ) {
			return false;
		}
		if ( is_multisite() || ! $user->has_cap( self::CAP ) ) {
			return false;
		}
		$allowed = array( self::ROLE, self::CAP, 'read', 'level_0', 'exist' );
		foreach ( $user->allcaps as $cap => $granted ) {
			if ( $granted && ! in_array( $cap, $allowed, true ) ) { return false; }
		}
		return true;
	}

	public static function enrolled_operator( $user ): bool {
		$email = self::email();
		return '' !== $email && self::eligible_operator( $user ) && hash_equals( $email, strtolower( $user->user_email ) );
	}

	private static function enrolled() {
		$email = self::email();
		$user = is_email( $email ) ? get_user_by( 'email', $email ) : false;
		return self::enrolled_operator( $user ) ? $user : false;
	}

	public static function prevent_password_login( $user ) {
		return self::operator_role( $user ) ? new \WP_Error( 'tc_front_sign_in_only', 'Use the Estimate Builder sign-in page.' ) : $user;
	}

	public static function prevent_password_reset( $allowed, $user_id ) {
		return self::operator_role( get_user_by( 'id', $user_id ) ) ? false : $allowed;
	}

	public static function prevent_app_passwords( $allowed, $user ) {
		return self::operator_role( $user ) ? false : $allowed;
	}

	public static function toolbar( $visible ) {
		return self::operator_role( wp_get_current_user() ) ? false : $visible;
	}

	public static function protect_dashboard(): void {
		if ( ! self::operator_role( wp_get_current_user() ) ) { return; }
		$action = is_string( $_REQUEST['action'] ?? null ) ? $_REQUEST['action'] : '';
		if ( wp_doing_ajax() && 'tc_estimate_rest_nonce' === $action ) { return; }
		wp_die( 'This account is for the Estimate Builder only.', '', array( 'response' => 403 ) );
	}

	public static function protect_rest( $response, $server, $request ) {
		if ( self::operator_role( wp_get_current_user() ) && ! str_starts_with( $request->get_route(), '/' . TC_ESTIMATE_REST_NS . '/' ) ) {
			return new \WP_Error( 'tc_front_sign_in_only', 'This account is for the Estimate Builder only.', array( 'status' => 403 ) );
		}
		return $response;
	}

	private static function on_builder(): bool {
		$post = get_queried_object();
		return is_page( 'estimate-builder' ) && $post instanceof \WP_Post && has_shortcode( $post->post_content, 'tc_estimate_builder' );
	}

	private static function origin( string $url ): string {
		$p = wp_parse_url( $url );
		if ( ! is_array( $p ) || 'https' !== strtolower( $p['scheme'] ?? '' ) || empty( $p['host'] ) || isset( $p['user'] ) || isset( $p['pass'] ) ) { return ''; }
		$port = (int) ( $p['port'] ?? 443 );
		return 'https://' . strtolower( $p['host'] ) . ( 443 === $port ? '' : ':' . $port );
	}

	private static function same_origin(): bool {
		$home = self::origin( home_url( '/' ) );
		if ( '' === $home || ( isset( $_SERVER['HTTP_SEC_FETCH_SITE'] ) && 'same-origin' !== $_SERVER['HTTP_SEC_FETCH_SITE'] ) ) { return false; }
		$source = $_SERVER['HTTP_ORIGIN'] ?? $_SERVER['HTTP_REFERER'] ?? '';
		return is_string( $source ) && hash_equals( $home, self::origin( $source ) );
	}

	public static function handle(): void {
		if ( '' === self::email() || ! self::on_builder() ) { return; }
		if ( ! defined( 'DONOTCACHEPAGE' ) ) { define( 'DONOTCACHEPAGE', true ); }
		nocache_headers();
		header( 'Referrer-Policy: same-origin' );
		$action = $_POST['tc_staff_action'] ?? '';
		if ( 'POST' !== ( $_SERVER['REQUEST_METHOD'] ?? '' ) || ! is_string( $action ) || ! in_array( $action, array( 'send', 'verify' ), true ) ) { return; }
		if ( headers_sent() || ! is_ssl() || ! self::same_origin() || is_user_logged_in() ) {
			wp_die( 'Open the Estimate Builder directly to sign in.', '', array( 'response' => 403 ) );
		}
		$user = self::enrolled();
		$email = $_POST['tc_staff_email'] ?? '';
		if ( $user && 'send' === $action && is_string( $email ) && strlen( $email ) < 256 && hash_equals( self::email(), strtolower( trim( $email ) ) ) ) {
			self::send( $user );
		}
		if ( $user && 'verify' === $action ) {
			$code = $_POST['tc_staff_code'] ?? '';
			$browser = $_COOKIE[ self::COOKIE ] ?? '';
			if ( is_string( $code ) && is_string( $browser ) && self::verify( $user, trim( $code ), $browser ) ) {
				self::cookie( '', time() - 3600 );
				wp_set_current_user( $user->ID );
				wp_set_auth_cookie( $user->ID, '1' === ( $_POST['tc_staff_remember'] ?? '' ), true );
				do_action( 'wp_login', $user->user_login, $user );
				self::back( '' );
			}
		}
		self::back( 'send' === $action ? 'sent' : 'retry' );
	}

	private static function back( string $status ): never {
		$url = get_permalink();
		wp_safe_redirect( '' === $status ? $url : add_query_arg( 'staff-sign-in', $status, $url ), 303 );
		exit;
	}

	private static function cookie( string $value, int $expires ): bool {
		return setcookie( self::COOKIE, $value, array( 'expires' => $expires, 'path' => '/', 'secure' => true, 'httponly' => true, 'samesite' => 'Strict' ) );
	}

	private static function digest( \WP_User $user, string $part ): string {
		return hash_hmac( 'sha256', 'tc-estimate-staff-v1:' . $user->ID . ':' . self::email() . ':' . $part, wp_salt( 'secure_auth' ) );
	}

	/** Read/write directly: no object-cache use and one compare-and-swap winner. */
	private static function load(): array {
		global $wpdb;
		$raw = $wpdb->get_var( $wpdb->prepare( "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s", self::STORE ) );
		$state = is_string( $raw ) ? json_decode( $raw, true ) : null;
		return array( $raw, is_array( $state ) ? $state : array() );
	}

	private static function save( $raw, array $state ): bool {
		global $wpdb;
		$value = wp_json_encode( $state );
		if ( false === $value ) { return false; }
		if ( null === $raw ) {
			return 1 === $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')", self::STORE, $value ) );
		}
		return 1 === $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->options} SET option_value = %s WHERE option_name = %s AND BINARY option_value = BINARY %s", $value, self::STORE, $raw ) );
	}

	private static function send( \WP_User $user ): void {
		$challenge = self::issue( $user );
		if ( $challenge && self::cookie( $challenge['browser'], $challenge['expires'] ) ) {
			wp_mail( $user->user_email, 'Your Estimate Builder sign-in code', "Your sign-in code is: " . $challenge['code'] . "\n\nIt expires in 10 minutes and works only in the browser that requested it. If you did not request this code, ignore this message." );
		}
	}

	private static function issue( \WP_User $user ): ?array {
		$now = time();
		list( $raw, $state ) = self::load();
		$sends = array_values( array_filter( (array) ( $state['sends'] ?? array() ), static fn( $ts ) => is_int( $ts ) && $ts > $now - 3600 ) );
		if ( count( $sends ) >= self::SENDS_PER_HOUR || $now - (int) ( end( $sends ) ?: 0 ) < 60 ) { return null; }
		$browser = bin2hex( random_bytes( 32 ) );
		$code = sprintf( '%08d', random_int( 0, 99999999 ) );
		$sends[] = $now;
		$next = array( 'sends' => $sends, 'expires' => $now + self::LIFETIME, 'tries' => self::TRIES, 'proof' => self::digest( $user, $browser ), 'code' => self::digest( $user, $browser . ':' . $code ) );
		return self::save( $raw, $next ) ? array( 'code' => $code, 'browser' => $browser, 'expires' => $next['expires'] ) : null;
	}

	private static function verify( \WP_User $user, string $code, string $browser ): bool {
		if ( ! preg_match( '/^[0-9]{8}$/D', $code ) || ! preg_match( '/^[a-f0-9]{64}$/D', $browser ) ) { return false; }
		list( $raw, $state ) = self::load();
		if ( $raw === null || (int) ( $state['expires'] ?? 0 ) <= time() || (int) ( $state['tries'] ?? 0 ) < 1 ||
			! hash_equals( (string) ( $state['proof'] ?? '' ), self::digest( $user, $browser ) ) ) { return false; }
		$matched = hash_equals( (string) ( $state['code'] ?? '' ), self::digest( $user, $browser . ':' . $code ) );
		if ( $matched ) { $state = array( 'sends' => $state['sends'] ?? array() ); }
		else { --$state['tries']; }
		// Fail closed if the record changed in flight. Consume before setting any session.
		return self::save( $raw, $state ) && $matched;
	}

	public static function form(): string {
		if ( ! is_ssl() || ! self::on_builder() || ! is_email( self::email() ) ) { return ''; }
		$status = $_GET['staff-sign-in'] ?? '';
		$has_cookie = is_string( $_COOKIE[ self::COOKIE ] ?? null ) && preg_match( '/^[a-f0-9]{64}$/D', $_COOKIE[ self::COOKIE ] );
		$dest = esc_url( get_permalink() );
		$html = '<section aria-label="Staff sign-in" style="max-width:32rem;margin:1.5rem auto;padding:1.25rem;background:#f6f7f7;border-left:4px solid #214c7a"><h2>Estimate Builder sign-in</h2>';
		if ( 'sent' === $status ) { $html .= '<p role="status">Check your work inbox for a code. If none arrives, wait a minute before requesting another.</p>'; }
		if ( 'retry' === $status ) { $html .= '<p role="status">That code did not work. Try again here, or request a new code after a minute.</p>'; }
		if ( $has_cookie ) {
			$html .= '<form method="post" action="' . $dest . '"><input type="hidden" name="tc_staff_action" value="verify"><label for="tc-staff-code">8-digit code</label><br><input id="tc-staff-code" name="tc_staff_code" required inputmode="numeric" autocomplete="one-time-code" pattern="[0-9]{8}" minlength="8" maxlength="8"><br><label><input type="checkbox" name="tc_staff_remember" value="1"> Keep me signed in on this work device</label><br><button type="submit">Open Estimate Builder</button></form>';
		}
		$html .= '<form method="post" action="' . $dest . '"><input type="hidden" name="tc_staff_action" value="send"><label for="tc-staff-email">Work email</label><br><input id="tc-staff-email" name="tc_staff_email" type="email" autocomplete="email" maxlength="254" required><br><button type="submit">' . ( $has_cookie ? 'Send a new code' : 'Email me a sign-in code' ) . '</button></form></section>';
		return $html;
	}
}
